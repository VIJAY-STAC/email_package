### This package is used to send a mail .

### To install this package